import fs from 'fs';
import path from 'path';
import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import dotenv from 'dotenv';

/**
 * Main backend entrypoint for AWS Elastic Beanstalk (and local dev).
 *
 * EB expects the app to listen on process.env.PORT.
 * MongoDB Atlas connection string must be provided via MONGODB_URI.
 */

// ---- Environment variables ----
// EB sets env vars via "Environment properties".
// For local dev, load `.env` (and optionally ENV_FILE / env.local).
dotenv.config();

if (process.env.ENV_FILE) {
  const explicitPath = path.resolve(process.cwd(), process.env.ENV_FILE);
  if (fs.existsSync(explicitPath)) dotenv.config({ path: explicitPath, override: true });
}

const envLocalPath = path.resolve(process.cwd(), 'env.local');
if (fs.existsSync(envLocalPath)) dotenv.config({ path: envLocalPath, override: true });

const app = express();

// ---- CORS (STRICT, as requested) ----
app.use(
  cors({
    origin: ['https://the-happy-oven.vercel.app', 'http://localhost:5173'],
    credentials: true
  })
);

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// MongoDB Connection
const { MONGODB_URI } = process.env;
if (!MONGODB_URI) {
  console.error('❌ Missing MONGODB_URI. Set it in Elastic Beanstalk Environment properties or in a local .env file.');
  process.exit(1);
}

mongoose
  .connect(MONGODB_URI)
  .then(() => console.log('✅ Connected to MongoDB'))
  .catch((error) => {
    console.error('❌ MongoDB connection error:', error);
    process.exit(1);
  });

// Routes
import authRoutes from './routes/auth.js';
import orderRoutes from './routes/orders.js';
app.use('/api/auth', authRoutes);
app.use('/api/orders', orderRoutes);

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', message: 'Server is running' });
});

// Start server (VERY IMPORTANT)
const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`✅ Backend running on port ${PORT}`);
});


